package com.ecommerce.eshop.controller;

import com.ecommerce.eshop.service.CartService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/cart")
public class CartController {
    
    @Autowired
    private CartService cartService;
    
    private String getSessionId(HttpServletRequest request) {
        return request.getSession().getId();
    }
    
    @GetMapping
    public String viewCart(Model model, HttpServletRequest request) {
        String sessionId = getSessionId(request);
        model.addAttribute("cartItems", cartService.getCartItems(sessionId));
        model.addAttribute("cartTotal", cartService.getCartTotal(sessionId));
        model.addAttribute("sessionId", sessionId);
        return "cart";
    }
    
    @PostMapping("/add/{productId}")
    public String addToCart(@PathVariable Long productId, HttpServletRequest request) {
        String sessionId = getSessionId(request);
        
        // DEBUG MESSAGES
        System.out.println("=== CART DEBUG ===");
        System.out.println("Adding product ID: " + productId);
        System.out.println("Session ID: " + sessionId);
        
        cartService.addToCart(productId, sessionId);
        
        // Check what's in cart after adding
        var items = cartService.getCartItems(sessionId);
        System.out.println("Cart now has " + items.size() + " items");
        items.forEach(item -> 
            System.out.println(" - " + item.getProduct().getName() + " x " + item.getQuantity())
        );
        System.out.println("==================");
        
        return "redirect:/";
    }

    // ADD THIS METHOD TO HANDLE GET REQUESTS FROM LINKS
    @GetMapping("/add/{productId}")
    public String addToCartGet(@PathVariable Long productId, HttpServletRequest request) {
        String sessionId = getSessionId(request);
        System.out.println("🛒 ADDING TO CART (GET): Product " + productId + " for session " + sessionId);
        cartService.addToCart(productId, sessionId);
        return "redirect:/";
    }
    
    @PostMapping("/remove/{itemId}")
    public String removeFromCart(@PathVariable Long itemId) {
        cartService.removeFromCart(itemId);
        return "redirect:/cart";
    }
    
    @PostMapping("/update")
    public String updateQuantity(@RequestParam Long itemId, @RequestParam Integer quantity) {
        cartService.updateQuantity(itemId, quantity);
        return "redirect:/cart";
    }
}