package com.ecommerce.eshop.controller;

import com.ecommerce.eshop.model.Order;
import com.ecommerce.eshop.service.CartService;
import com.ecommerce.eshop.service.OrderService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("/order")
public class OrderController {
    
    @Autowired
    private OrderService orderService;
    
    @Autowired
    private CartService cartService;
    
    private String getSessionId(HttpServletRequest request) {
        return request.getSession().getId();
    }
    
    @GetMapping("/checkout")
    public String checkout(Model model, HttpServletRequest request) {
        String sessionId = getSessionId(request);
        var cartItems = cartService.getCartItems(sessionId);
        
        if (cartItems.isEmpty()) {
            return "redirect:/cart";
        }
        
        model.addAttribute("order", new Order());
        model.addAttribute("cartItems", cartItems);
        model.addAttribute("cartTotal", cartService.getCartTotal(sessionId));
        model.addAttribute("sessionId", sessionId);
        return "checkout";
    }
    
    @PostMapping("/place")
    public String placeOrder(@ModelAttribute Order order, HttpServletRequest request) {
        try {
            String sessionId = getSessionId(request);
            System.out.println("=== PLACING ORDER ===");
            System.out.println("Customer: " + order.getCustomerName());
            System.out.println("Email: " + order.getEmail());
            System.out.println("Phone: " + order.getPhone());
            System.out.println("Address: " + order.getAddress());
            System.out.println("Session: " + sessionId);
            
            // Validate required fields
            if (order.getCustomerName() == null || order.getCustomerName().trim().isEmpty() ||
                order.getEmail() == null || order.getEmail().trim().isEmpty() ||
                order.getAddress() == null || order.getAddress().trim().isEmpty()) {
                System.out.println("Missing required fields!");
                return "redirect:/order/checkout";
            }
            
            Order savedOrder = orderService.createOrder(order, sessionId);
            System.out.println("Order placed successfully! ID: " + savedOrder.getId());
            
            return "redirect:/order/confirmation/" + savedOrder.getId();
        } catch (Exception e) {
            System.out.println("ERROR placing order: " + e.getMessage());
            e.printStackTrace();
            return "redirect:/cart";
        }
    }
    
    @GetMapping("/confirmation/{orderId}")
    public String orderConfirmation(@PathVariable Long orderId, Model model) {
        try {
            System.out.println("Loading order confirmation for ID: " + orderId);
            Optional<Order> orderOpt = orderService.getOrderById(orderId);
            
            if (orderOpt.isPresent()) {
                Order order = orderOpt.get();
                System.out.println("Order found: " + order.getCustomerName() + " - $" + order.getTotalAmount());
                model.addAttribute("order", order);
            } else {
                System.out.println("Order not found with ID: " + orderId);
                // Still return confirmation page but without order data
            }
            return "confirmation";
        } catch (Exception e) {
            System.out.println("Error loading order confirmation: " + e.getMessage());
            e.printStackTrace();
            return "confirmation";
        }
    }
    @GetMapping("/orders")
    public String viewAllOrders(Model model) {
        model.addAttribute("orders", orderService.getAllOrders());
        return "orders";
    }
}