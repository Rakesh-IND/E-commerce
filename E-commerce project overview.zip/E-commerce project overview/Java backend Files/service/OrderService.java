package com.ecommerce.eshop.service;

import com.ecommerce.eshop.model.CartItem;
import com.ecommerce.eshop.model.Order;
import com.ecommerce.eshop.model.OrderItem;
import com.ecommerce.eshop.repository.OrderRepository;
import com.ecommerce.eshop.repository.OrderItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {
    
    @Autowired
    private OrderRepository orderRepository;
    
    @Autowired
    private OrderItemRepository orderItemRepository;
    
    @Autowired
    private CartService cartService;
    
    @Transactional
    public Order createOrder(Order order, String sessionId) {
        System.out.println("=== ORDER SERVICE: createOrder STARTED ===");
        System.out.println("Session ID: " + sessionId);
        System.out.println("Customer: " + order.getCustomerName());
        
        try {
            // Check if cart has items
            List<CartItem> cartItems = cartService.getCartItems(sessionId);
            System.out.println("Cart items count: " + cartItems.size());
            
            if (cartItems.isEmpty()) {
                System.out.println("ERROR: Cart is empty! Cannot create order.");
                throw new RuntimeException("Cart is empty");
            }
            
            // Calculate total amount
            Double totalAmount = 0.0;
            for (CartItem item : cartItems) {
                double itemTotal = item.getProduct().getPrice() * item.getQuantity();
                totalAmount += itemTotal;
                System.out.println("Cart Item: " + item.getProduct().getName() + 
                                 " x " + item.getQuantity() + " = $" + itemTotal);
            }
            
            System.out.println("Total amount calculated: $" + totalAmount);
            order.setTotalAmount(totalAmount);
            
            // Save the order
            System.out.println("Saving order to database...");
            Order savedOrder = orderRepository.save(order);
            System.out.println("Order saved with ID: " + savedOrder.getId());
            
            // Create order items
            System.out.println("Creating order items...");
            for (CartItem cartItem : cartItems) {
                OrderItem orderItem = new OrderItem(cartItem.getProduct(), cartItem.getQuantity());
                orderItem.setOrder(savedOrder);
                orderItemRepository.save(orderItem);
                System.out.println("Order item saved: " + cartItem.getProduct().getName());
            }
            
            // Clear the cart - this will now work within the transaction
            System.out.println("Clearing cart for session: " + sessionId);
            cartService.clearCart(sessionId);
            
            // Verify cart is cleared
            List<CartItem> remainingItems = cartService.getCartItems(sessionId);
            System.out.println("Cart items after clearing: " + remainingItems.size());
            
            System.out.println("=== ORDER SERVICE: createOrder COMPLETED SUCCESSFULLY ===");
            return savedOrder;
            
        } catch (Exception e) {
            System.out.println("=== ORDER SERVICE: createOrder FAILED ===");
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Order creation failed: " + e.getMessage(), e);
        }
    }
    
    public List<Order> getAllOrders() {
        List<Order> orders = orderRepository.findAll();
        System.out.println("Found " + orders.size() + " orders in database");
        return orders;
    }
    
    public Optional<Order> getOrderById(Long id) {
        System.out.println("Looking for order with ID: " + id);
        Optional<Order> order = orderRepository.findById(id);
        if (order.isPresent()) {
            System.out.println("Order found: " + order.get().getCustomerName());
        } else {
            System.out.println("Order not found with ID: " + id);
        }
        return order;
    }
}