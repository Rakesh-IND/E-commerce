package com.ecommerce.eshop.service;

import com.ecommerce.eshop.model.Product;
import com.ecommerce.eshop.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;  // ADD THIS IMPORT
import java.util.List;
import java.util.Optional;

@Service
public class ProductService {
    
    @Autowired
    private ProductRepository productRepository;
    
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }
    
    public Optional<Product> getProductById(Long id) {
        return productRepository.findById(id);
    }
    
    public List<Product> searchProducts(String query) {
        System.out.println("=== SEARCH DEBUG ===");
        System.out.println("Search query received: '" + query + "'");
        
        try {
            List<Product> results = productRepository.searchProducts(query);
            System.out.println("Search found " + results.size() + " products");
            
            for (Product p : results) {
                System.out.println(" - " + p.getName() + " | " + p.getCategory());
            }
            
            // If no results, show all products for debugging
            if (results.isEmpty()) {
                System.out.println("NO RESULTS - Showing all products for debug:");
                List<Product> allProducts = productRepository.findAll();
                for (Product p : allProducts) {
                    System.out.println(" - " + p.getName() + " | " + p.getCategory() + " | " + p.getDescription());
                }
            }
            
            System.out.println("==================");
            return results;
            
        } catch (Exception e) {
            System.out.println("SEARCH ERROR: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();  // This line needs ArrayList import
        }
    }
    
    public List<Product> getProductsByCategory(String category) {
        return productRepository.findByCategory(category);
    }
}