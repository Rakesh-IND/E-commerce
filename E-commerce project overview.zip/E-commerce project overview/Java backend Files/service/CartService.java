package com.ecommerce.eshop.service;

import com.ecommerce.eshop.model.CartItem;
import com.ecommerce.eshop.model.Product;
import com.ecommerce.eshop.repository.CartItemRepository;
import com.ecommerce.eshop.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional; // ADD THIS IMPORT

import java.util.List;
import java.util.Optional;

@Service
public class CartService {
    
    @Autowired
    private CartItemRepository cartItemRepository;
    
    @Autowired
    private ProductRepository productRepository;
    
    public void addToCart(Long productId, String sessionId) {
        Optional<Product> productOpt = productRepository.findById(productId);
        if (productOpt.isPresent()) {
            CartItem existingItem = cartItemRepository.findByProductIdAndSessionId(productId, sessionId);
            
            if (existingItem != null) {
                existingItem.setQuantity(existingItem.getQuantity() + 1);
                cartItemRepository.save(existingItem);
            } else {
                CartItem newItem = new CartItem(productOpt.get(), 1, sessionId);
                cartItemRepository.save(newItem);
            }
        }
    }
    
    public List<CartItem> getCartItems(String sessionId) {
        return cartItemRepository.findBySessionId(sessionId);
    }
    
    public void removeFromCart(Long itemId) {
        cartItemRepository.deleteById(itemId);
    }
    
    public void updateQuantity(Long itemId, Integer quantity) {
        Optional<CartItem> itemOpt = cartItemRepository.findById(itemId);
        if (itemOpt.isPresent() && quantity > 0) {
            CartItem item = itemOpt.get();
            item.setQuantity(quantity);
            cartItemRepository.save(item);
        }
    }
    
    @Transactional // ADD THIS ANNOTATION
    public void clearCart(String sessionId) {
        cartItemRepository.deleteBySessionId(sessionId);
    }
    
    public Double getCartTotal(String sessionId) {
        List<CartItem> items = getCartItems(sessionId);
        return items.stream()
                .mapToDouble(CartItem::getTotalPrice)
                .sum();
    }
    
    public int getCartItemCount(String sessionId) {
        List<CartItem> items = getCartItems(sessionId);
        return items.stream()
                .mapToInt(CartItem::getQuantity)
                .sum();
    }
}