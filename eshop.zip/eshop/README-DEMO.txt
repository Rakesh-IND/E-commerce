=== E-SHOP E-COMMERCE PORTAL DEMO ===

QUICK START:
1. Double-click "demo-eshop.bat" (RECOMMENDED)
   - OR -
   Double-click "start-eshop.bat"

2. Wait for server to start (30-60 seconds)
   You'll see: "Started EshopApplication"

3. Open browser to: http://localhost:8081/

4. Demo the features:
   - Register new account
   - Login with your account
   - Browse products
   - Add items to cart
   - Checkout and place order

FEATURES DEMONSTRATED:
✅ User Authentication (Login/Register)
✅ Product Catalog with Search & Filters
✅ Shopping Cart System
✅ Checkout & Order Processing
✅ Database Integration
✅ Responsive Web Design

TECHNOLOGY STACK:
- Backend: Java Spring Boot
- Frontend: HTML, CSS, JavaScript
- Database: H2 (In-memory)
- Build Tool: Maven

NOTE: This is a development demo. The backend needs to be running for the website to work.

TO STOP: Close the command prompt window running the backend.

Created for College Project - Full Stack E-Commerce Portal