package com.ecommerce.eshop.controller;

import com.ecommerce.eshop.model.Product;
import com.ecommerce.eshop.service.ProductService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class HomeController {
    
    @Autowired
    private ProductService productService;
    
    private String getSessionId(HttpServletRequest request) {
        return request.getSession().getId();
    }
    
    @GetMapping("/")
    public String home(Model model, HttpServletRequest request) {
        List<Product> products = productService.getAllProducts();
        model.addAttribute("products", products);
        model.addAttribute("sessionId", getSessionId(request));
        return "index";
    }
    
    @GetMapping("/search")
    public String searchProducts(@RequestParam String query, Model model, HttpServletRequest request) {
        System.out.println("📍 HOME CONTROLLER SEARCH: '" + query + "'");
        List<Product> products = productService.searchProducts(query);
        model.addAttribute("products", products);
        model.addAttribute("searchQuery", query);
        model.addAttribute("sessionId", getSessionId(request));
        return "index";
    }
    
    @GetMapping("/category")
    public String filterByCategory(@RequestParam String category, Model model, HttpServletRequest request) {
        List<Product> products = productService.getProductsByCategory(category);
        model.addAttribute("products", products);
        model.addAttribute("selectedCategory", category);
        model.addAttribute("sessionId", getSessionId(request));
        return "index";
    }
}