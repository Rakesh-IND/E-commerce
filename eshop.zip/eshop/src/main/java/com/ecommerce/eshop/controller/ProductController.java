package com.ecommerce.eshop.controller;

import com.ecommerce.eshop.model.Product;
import com.ecommerce.eshop.service.ProductService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Optional;

@Controller
public class ProductController {
    
    @Autowired
    private ProductService productService;
    
    private String getSessionId(HttpServletRequest request) {
        return request.getSession().getId();
    }
    
    @GetMapping("/product/{id}")
    public String productDetails(@PathVariable Long id, Model model, HttpServletRequest request) {
        Optional<Product> product = productService.getProductById(id);
        if (product.isPresent()) {
            model.addAttribute("product", product.get());
            model.addAttribute("sessionId", getSessionId(request));
            return "product";
        }
        return "redirect:/";
    }
}