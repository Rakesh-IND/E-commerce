package com.ecommerce.eshop.config;

import com.ecommerce.eshop.model.Product;
import com.ecommerce.eshop.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private ProductRepository productRepository;

    @Override
    public void run(String... args) throws Exception {
        // Add sample products
        if (productRepository.count() == 0) {
            productRepository.save(new Product(
                "MacBook Pro 16\"",
                "Apple MacBook Pro 16-inch with M3 Pro chip, 18GB RAM, 512GB SSD",
                2399.99,
                "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=500",
                "Laptop"
            ));

            productRepository.save(new Product(
                "Dell XPS 13",
                "Dell XPS 13 laptop with Intel i7 processor, 16GB RAM, 1TB SSD",
                1299.99,
                "https://images.unsplash.com/photo-1593642702821-c8da6771f0c6?w=500",
                "Laptop"
            ));

            productRepository.save(new Product(
                "iPhone 15 Pro",
                "Apple iPhone 15 Pro with 128GB storage, Titanium design",
                999.99,
                "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=500",
                "Smartphone"
            ));

            productRepository.save(new Product(
                "Samsung Galaxy S24",
                "Samsung Galaxy S24 with 256GB storage, 8GB RAM",
                849.99,
                "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=500",
                "Smartphone"
            ));

            productRepository.save(new Product(
                "Sony WH-1000XM5",
                "Sony WH-1000XM5 wireless noise-canceling headphones",
                399.99,
                "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500",
                "Headphones"
            ));

            productRepository.save(new Product(
                "Apple AirPods Pro",
                "Apple AirPods Pro with MagSafe Charging Case",
                249.99,
                "https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=500",
                "Headphones"
            ));

            productRepository.save(new Product(
                "iPad Air",
                "Apple iPad Air with M1 chip, 64GB, Wi-Fi",
                599.99,
                "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=500",
                "Tablet"
            ));

            productRepository.save(new Product(
                "Samsung Galaxy Tab S9",
                "Samsung Galaxy Tab S9 with S Pen, 128GB",
                799.99,
                "https://images.unsplash.com/photo-1561154464-82e9adf32764?w=500",
                "Tablet"
            ));

            System.out.println("Sample products loaded successfully!");
        }
    }
}